package com.javainuse.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.javainuse.model.Customer;
import com.javainuse.model.Employee;
import com.javainuse.service.CustomerService;
import com.tcs1.model.Student;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api")
public class TestController {
	@Autowired
	CustomerService customerService;
	@GetMapping("/customer")   
	private List<Customer> getAllCustomer() 
	{
	return customerService.getAllCustomer();
	}
	
	@GetMapping("/customer/{custId}")     
	//@Produces(MediaType.APPLICATION_JSON)
	private Customer getStudent(@PathVariable("custId") int custId) 
	{
	return customerService.getStudentById(custId);
	}
	
	@DeleteMapping("/customer/{custId}")
	private void deleteCustomer(@PathVariable("custId") int custId) 
	{
	customerService.delete(custId);
	}
	
	@PostMapping("/customer")
	private ResponseEntity<Integer> saveStudent(@RequestBody Customer customer) 
	{
	customerService.saveOrUpdate(customer);
	return new ResponseEntity(customer.getCustId(),HttpStatus.OK);
	}
	
	@PutMapping("/customer")
	private String updateCustomer(@RequestBody Customer customer) {
		
		Customer customer1=new Customer();
		customer1.setName(customer.getName());
		customer1.setAge(customer.getAge());
		customer1.setAddress(customer.getAddress());
		customer1.setTypeOfAccount(customer.getTypeOfAccount());
		customerService.saveOrUpdate(customer1);
		return "Updated Successfully";
	}


}
